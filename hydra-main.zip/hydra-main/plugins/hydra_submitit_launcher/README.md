# Hydra Submitit Launcher
Provides a [`Submitit`](https://github.com/facebookincubator/submitit) based Hydra Launcher supporting [SLURM ](https://slurm.schedmd.com/documentation.html).

See [website](https://hydra.cc/docs/plugins/submitit_launcher) for more information