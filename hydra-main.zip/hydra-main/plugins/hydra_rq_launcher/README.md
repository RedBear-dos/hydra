# Hydra RQ Launcher
Provides a [Redis Queue (RQ)](https://python-rq.org) launcher for Hydra supporting distributed execution and job queuing.

See [website](https://hydra.cc/docs/plugins/rq_launcher) for more information
