## Jupyter notebooks

- **compose_configs_in_notebook.ipynb** [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/facebookresearch/hydra/main?filepath=examples%2Fjupyter_notebooks%2Fcompose_configs_in_notebook.ipynb)
