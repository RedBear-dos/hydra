# Attribution

The following sets forth attribution notices for third-party software that may be contains in portions of this software.
## Namespace packages
The plugins system is inspired by the 'native' example from [Python Namespace Package Examples](https://github.com/pypa/sample-namespace-packages)
Released under [Apache license](LICENSE-sample-namespace-packages)

## ANTLR
Hydra is using ANTLR4 for various data parsing tasks.
The ANTLR4 tool is included in the repository and in addition the packaged library contains ANTLR4 generated code. 

Released under [BSD and MIT licenses](LICENSE-antlr4)
