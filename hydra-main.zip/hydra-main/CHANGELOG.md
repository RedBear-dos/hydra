Please see [NEWS.md](/NEWS.md) for an updated change log.
